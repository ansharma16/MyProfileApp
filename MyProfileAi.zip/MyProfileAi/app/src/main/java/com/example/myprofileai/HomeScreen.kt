package com.example.myprofileai

import androidx.compose.ui.text.style.TextDirection.Companion.Content
import android.media.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.myprofileai.ui.theme.whiteB
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CardElevation
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.example.myprofileai.ui.theme.Pink40
import com.example.myprofileai.ui.theme.Typography
import com.example.myprofileai.ui.theme.Purple40
import com.example.myprofileai.ui.theme.PurpleGrey40
import com.google.ai.client.generativeai.type.content

@Composable

fun HomeScreen(){
    Column(modifier = Modifier.fillMaxSize()
        .background(color = Color.LightGray)
        .padding(top=50.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Header()

        Column(modifier=Modifier.
            fillMaxWidth()
            .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ){
            Section("Bio")
            ContentCard{

                Text("I am Ansh Sharma. 3rd year ENC student. This is my first Android App", fontSize = 15.sp,
                    lineHeight = 30.sp,
                    color = Color.Black,
                    modifier = Modifier.padding(16.dp))

            }

            Section("Education")
            ContentCard{
                Column{
                    Column(modifier=Modifier.fillMaxWidth().padding(16.dp)){
                        Text(text="CGPA: 8.07" +
                                " Class 12: 87% ",color=Color.Black,fontSize=16.sp, fontWeight = FontWeight.Bold)

                        Text(text="Thapar Institute of Engineering & Technology",color=Color.DarkGray,fontSize=14.sp, fontWeight = FontWeight.Bold)
                        Divider(modifier = Modifier.padding(vertical = 16.dp))
                        Text(text= " Class 10: 91% ",color=Color.Black,fontSize=16.sp, fontWeight = FontWeight.Bold)

                        Text(text="Him Academy Public School",color=Color.DarkGray,fontSize=14.sp, fontWeight = FontWeight.Bold)
                        Divider(modifier = Modifier.padding(vertical = 16.dp))
                    }
                }
            }
            Section("Achievements")
            ContentCard{
                Column(verticalArrangement = Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth().padding(16.dp)){
                    Text(text="Solved over 200 problems on LeetCode",color=Color.Black,fontSize=16.sp)
                    Divider(modifier = Modifier.padding(vertical = 16.dp))
                    Text(text="Completed Certified course on Android App Development",color=Color.Black,fontSize=16.sp)
                }
            }

            }
        }
    }




@Composable
fun Header(){
    Card(modifier = Modifier.padding(horizontal=16.dp,
        vertical = 9.dp)
        .fillMaxWidth(), colors = CardDefaults.cardColors(whiteB),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()
            .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.foundation.Image(
                painter = painterResource(id=R.drawable.profilepic),
                "profile picture",
                modifier = Modifier.size(120.dp)
                    .clip(shape = CircleShape),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Ansh Sharma",
                style = Typography.headlineMedium,
                textAlign = TextAlign.Center,
                color=Purple40
            )

            Text(
                "1024150122",
                style = Typography.bodyLarge,
                textAlign = TextAlign.Center,
                color=Color.DarkGray
            )
        }
    }


}
@Composable
fun Section(title: String){
    Text(
        text=title,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color=Purple40,
        modifier=Modifier.padding(bottom=4.dp)

    )
}

@Composable
fun ContentCard(content: @Composable ()->Unit){
    Card(modifier=Modifier.
    fillMaxWidth(),shape= RoundedCornerShape(12.dp),
        colors= CardDefaults.cardColors(whiteB),
        elevation = CardDefaults.cardElevation(1.dp)
    ){
        content()
    }
}


